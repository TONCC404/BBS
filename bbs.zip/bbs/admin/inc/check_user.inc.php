<?php
    if(empty($_POST['user_name'])){
        skip('user_add.php','error','管理员名称不得为空！！');
     }

     if(mb_strlen($_POST['user_name'])>32){
        skip('user_add.php','error','管理员名称不得多于32个字符！！');
     }
     
     if(mb_strlen($_POST['user_pw'])<6){
        skip('user_add.php','error','密码不得少于6位！！');
     }
     
     $_POST=escape($link,$_POST);
     $query="select * from ton_member where name='{$_POST['user_name']}'";
     $result=execute($link,$query);
  
     

    
?>
     