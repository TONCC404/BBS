<?php 
include_once '../inc/config.inc.php';
include_once '../inc/mysql.inc.php';
include_once '../inc/tool.inc.php';

$link=connect();
include_once  'inc/is_manage_login.inc.php'; //验证管理员是否登录


$template['title']='管理员列表页';
$template['css']=array('style/public.css');
?>

<?php include 'inc/header.inc.php'?>

<div id="main" style="height:1000px;">
		<div class="title">管理员列表</div>

		
		<table class="list">
			<tr>
				<th>名称</th>	 	 	
				<th>等级</th>
				<th>创建日期</th>
                <th>操作</th>
			</tr>

			<?php 
			 //执行数据库查询
			 $query="select * from ton_manage";
			 $result=execute($link,$query);
			 //如果有结果，进行输出
			 while($data=mysqli_fetch_assoc($result)){
                 if($data['level']==0){
                     $data['level']='超级管理员';

                 }

                 else{
                     $data['level']='普通管理员';
                 }
				
				 $url=urlencode("manage_delete.php?id={$data['id']}");
				 $return_url=urlencode($_SERVER['REQUEST_URI']);
				 $message="你真的要删除管理员{$data['name']}";
				 $delete_url="confirm.php?url={$url}&return_url={$return_url}&message={$message}"; 

                

				 
// <<<A A 是一种定界符，在php语言中插入html语句				 
$html=<<<A
				<tr>
					<td>{$data['name']} [id:{$data['id']}]</td>
					<td>{$data['level']}</td>
                    <td>{$data['create_time']}</td>
					<td><a href="{$delete_url}">[删除]</a></td>
				</tr>
A;

             echo $html;
			 }
			?>
			

		</table>
		<input class="btn" type="submit" name="submit" value="排序" />

	</div>



<?php include 'inc/footer.inc.php'?>