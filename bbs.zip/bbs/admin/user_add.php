<?php 
include_once '../inc/config.inc.php';
include_once '../inc/mysql.inc.php';
include_once '../inc/tool.inc.php';
$link=connect();

include_once  'inc/is_manage_login.inc.php'; //验证管理员是否登录


if(isset($_POST['submit'])){
    
    include 'inc/check_user.inc.php';
    if(mysqli_num_rows($result)){
        skip('user_add.php','error','这个名称已经存在。。');
     }
    $query="insert into ton_member(name,pw,register_time) values('{$_POST['user_name']}',md5({$_POST['user_pw']}),now())";
     execute($link,$query);
     if(mysqli_affected_rows($link)==1){
         skip('user_manage.php','ok','恭喜你添加成功');}

     else{
         skip('user_add.php','error','对不起，添加失败,请重试！！');
     }



}


$template['title']='用户添加页';
$template['css']=array('style/public.css','style/father_module_add.css');
?>
<?php include_once 'inc/header.inc.php' ?>
<div id="main" style="height:1000px;">
	<div class="title" style="margin-bottom: 20px;">添加用户</div>
    <form method="post">
        <table class="au">
                <tr>
                    <td>用户名称</td>
                    <td><input name="user_name" type="text" /></td>
                    <td>
                        名称不得为空，不得超过32个字符
                    </td>
                </tr>
                <tr>
                    <td>密码</td>
                    <td><input name="user_pw" type="text" /></td>
                    <td>
                        不能少于6位
                    </td>
                </tr>
            </table>
            <input style="margin-top: 10px; cursor:pointer;" class="btn" type="submit" name="submit" value="添加" />
        </form>
       
</div>
<?php include_once 'inc/footer.inc.php' ?>