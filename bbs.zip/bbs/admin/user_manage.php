<?php 
include_once '../inc/config.inc.php';
include_once '../inc/mysql.inc.php';
include_once '../inc/tool.inc.php';

$link=connect();

$template['title']='用户列表页';
$template['css']=array('style/public.css');
?>
<?php include 'inc/header.inc.php'?>

<div id="main" style="height:1000px;">
		<div class="title">管理员列表</div>

		
		<table class="list">
			<tr>
				<th>名称</th>	 	 	 
				<th>创建日期</th>
                <th>操作</th>
			</tr>

			<?php 
			 //执行数据库查询
			 $query="select * from ton_member";
			 $result=execute($link,$query);
			 //如果有结果，进行输出
			 while($data=mysqli_fetch_assoc($result)){
                				
				 $url=urlencode("user_delete.php?id={$data['id']}");
				 $return_url=urlencode($_SERVER['REQUEST_URI']);
				 $message="你真的要删除用户{$data['name']}";
				 $delete_url="confirm.php?url={$url}&return_url={$return_url}&message={$message}"; 

                

				 
// <<<A A 是一种定界符，在php语言中插入html语句				 
$html=<<<A
				<tr>
					<td>{$data['name']} [id:{$data['id']}]</td>
                    <td>{$data['register_time']}</td>
					<td><a href="{$delete_url}">[删除]</a>&nbsp;&nbsp;<a href="user_update.php?id={$data['id']}">[编辑]</a>&nbsp;&nbsp;<a href="user_add.php">[添加]</a></td>
				</tr>
A;

             echo $html;
			 }
			?>
			

		</table>

	</div>

<?php include 'inc/footer.inc.php'?>