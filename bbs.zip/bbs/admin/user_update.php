<?php 
include_once '../inc/config.inc.php';
include_once '../inc/mysql.inc.php';
include_once '../inc/tool.inc.php';

$link=connect();

include_once 'inc/is_manage_login.inc.php';
if(!isset($_GET['id'])|| !is_numeric($_GET['id'])){ 
 skip('user_manage.php','error','参数错误！!');} 
$query="select * from ton_member where id={$_GET['id']}";
$result=execute($link,$query);
$data=mysqli_fetch_assoc($result);

if(!mysqli_num_rows($result)){
    skip('user_manage.php','error','该用户不存在！！');
}


if(isset($_POST['submit'])){
    $check_flag='update';
    //验证用户填写的信息
    
    if($data['name']==$_POST['user_name'] && $data['pw']==md5($_POST['user_pw'])){
        skip('user_update.php','error','您并没有做出修改，请重试！！');
    }

    else{
        include 'inc/check_user.inc.php';
        if(mysqli_num_rows($result) && $_POST['user_name']!=$data['name']){
            skip('user_add.php','error','这个名称已经存在。。');
        }

        $query="update ton_member set name='{$_POST['user_name']}',pw=md5({$_POST['user_pw']}) where id={$_GET['id']}";
        execute($link,$query);
        if(mysqli_affected_rows($link)==1){
            skip('user_manage.php','ok','修改成功！！');
        }
        else{
            skip('user_update.php','error','修改失败，请重试！！');
        }
     }
   
}


$template['title']='修改用户';
$template['css']=array('style/public.css');
?>
<?php include './inc/header.inc.php'?>
<div id="main" style="height:1000px;">
	<div class="title" style="margin-bottom: 20px;">修改用户<?php echo $data['name']?></div>
    <form method="post">
        <table class="au">
                <tr>
                    <td>用户名称</td>
                    <td><input name="user_name" value="<?php echo $data['name']?>" type="text" /></td>
                    <td>
                        用户名称不得为空，最大不得超过66个字符
                    </td>
                </tr>
                <tr>
                    <td>密码</td>
                    <td><input name="user_pw" value="<?php echo $data['pw']?>" type="text" /></td>
                    <td>
                        密码不得少于6个字符
                    </td>
                </tr>	
            </table>
            <input style="margin-top: 10px; cursor:pointer;" class="btn" type="submit" name="submit" value="修改" />
        </form>
       
</div>
<?php include './inc/footer.inc.php'?>