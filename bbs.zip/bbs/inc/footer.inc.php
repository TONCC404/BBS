<div id="footer" class="auto">
		<div class="bottom">
			<a>TON BBS</a>
		</div>
		<div class="copyright">Powered by ton ©2021 ton.com</div>
	</div>
</body>
</html>