<?php 
header('Content-type:image/jpeg');
$width=120;
$height=40;
$img=imagecreatetruecolor($width,$height);
$ColorBg=imagecolorallocate($img,rand(200-255),rand(200-255),rand(200-255));
imagefill($img,1000,1000,$ColorBg);
imagejpeg($img);


$red=imagecolorallocate($im,255,0,0);
$img1=imageellipse($im,20,20,20,20,$red);
imagejpeg($img1);
?>